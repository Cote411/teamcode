// package org.firstinspires.ftc.teamcode;

// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// import com.qualcomm.robotcore.hardware.DcMotorEx;
// import com.qualcomm.robotcore.hardware.DcMotor;

// @Autonomous

// public class Test1 {

//     private DcMotorEx Motor1;
    
    
    
//     public void init(){
        
//         waitForStart();
        
//         Motor1 = hardwareMap.get(DcMotorEx.class, "Port0");
        
        
//     }
    
    
// }